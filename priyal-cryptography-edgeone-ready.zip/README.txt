PRIYAL CRYPTOGRAPHY LAB - EDGEONE STATIC DEPLOYMENT

Deployment:
1. Upload this folder (or the ZIP) as a static website.
2. Make sure index.html is at the published/root directory.
3. No build command is required.
4. No Node.js, backend, database, API key, or environment variables are required.
5. For a long-lived public URL, use EdgeOne's persistent/production static hosting rather than a temporary Maker preview if your account/workspace distinguishes the two.

This project is a client-side HTML/CSS/JavaScript application. It does not require a process to remain running after deployment.
